#!/system/bin/sh
# one_click_disable_adb.sh - 一键关闭

echo "正在执行USB调试关闭操作..."
echo

# 记录操作日志
LOG_FILE="/sdcard/adb_disable.log"
echo "=== $(date) ===" >> $LOG_FILE

# 尝试多种方法
echo "1. 尝试通过settings命令..." | tee -a $LOG_FILE
settings put global adb_enabled 0 2>> $LOG_FILE
[ $? -eq 0 ] && echo "  ✓ 成功" || echo "  ✗ 失败"

echo "2. 停止ADB服务..." | tee -a $LOG_FILE
stop adbd 2>> $LOG_FILE
[ $? -eq 0 ] && echo "  ✓ 成功" || echo "  ✗ 失败"

echo "3. 清除网络ADB设置..." | tee -a $LOG_FILE
settings put global adb_wifi_enabled 0 2>> $LOG_FILE
[ $? -eq 0 ] && echo "  ✓ 成功" || echo "  ✗ 失败"

echo "4. 重启ADB服务..." | tee -a $LOG_FILE
start adbd 2>> $LOG_FILE
[ $? -eq 0 ] && echo "  ✓ 成功" || echo "  ✗ 失败"

# 验证结果
echo
echo "验证结果：" | tee -a $LOG_FILE
CURRENT_STATUS=$(settings get global adb_enabled)
if [ "$CURRENT_STATUS" = "0" ]; then
    echo "✅ USB调试已成功关闭" | tee -a $LOG_FILE
else
    echo "⚠️ USB调试可能仍然开启" | tee -a $LOG_FILE
    echo "建议：进入设置→开发者选项手动关闭" | tee -a $LOG_FILE
fi

echo
echo "操作日志已保存到: $LOG_FILE"
