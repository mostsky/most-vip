#!/system/bin/sh
# 删除 TWRP 文件夹，清理残留
rm -rf /data/media/0/TWRP
rm -r /storage/emulated/0/TWRP

rm -rf /data/local/tmp/shizuku/
rm -rf /data/local/tmp/shizuku_starter
rm -f /data/local/tmp/shizuku/
rm -f /data/local/tmp/shizuku_starter
#删除风险文件 过春秋清理的文件
rm -f /data/local/stryker
rm -f /data/system/AppRetention
rm -f /data/local/tmp/luckys
rm -f /data/local/tmp/input_devices
rm -f /data/local/tmp/HyperCeiler
rm -f /data/local/tmp/simpleHook
rm -f /data/local/tmp/DisabledAllGoogleServices
rm -f /data/local/MIO
rm -f /data/DNA
rm -f /data/local/tmp/cleaner_starter
rm -f /data/local/tmp/byyang
rm -f /data/local/tmp/mount_mask
rm -f /data/local/tmp/mount_mark
rm -f /data/local/tmp/scriptTMP
rm -f /data/local/luckys
rm -f /data/local/tmp/horae_control.log
rm -f /data/gpu_freq_table.conf
rm -f /storage/emulated/0/Download/advanced
rm -f /storage/emulated/0/Documents/advanced
rm -f /data/system/NoActive
rm -f /data/system/Freezer
rm -f /storage/emulated/0/Android/naki
rm -f /data/swap_config.conf
rm -f /data/local/tmp/resetprop
rm -f /data/local/tmp/yshell
rm -f /storage/emulated/0/Android/data/com.omarea.vtools/dev/scene
#删除 MT2 文件夹
rm -rf //storage/emulated/0/MT2

# adb调试痕迹
#!/system/bin/sh
resetprop persist.adb.nonblocking_ffs ""
# 执行
sh clean_adb_trace.sh




