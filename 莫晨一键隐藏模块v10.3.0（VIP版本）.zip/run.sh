#!/bin/sh
# 莫晨一键隐藏模块 - UI 接口修复版（run.sh）
# 用于 UI 按钮调用，自动提权执行对应功能

# 模块根路径（固定不变）
MODULE_PATH="/data/adb/modules/cufy5chu"
# 默认动作：一键顺序执行
ACTION="${1:-run}"

echo "[INFO] ======================================"
echo "[INFO] 莫晨一键隐藏模块 UI 接口启动"
echo "[INFO] 动作: $ACTION"
echo "[INFO] 模块路径: $MODULE_PATH"
echo "[INFO] ======================================"

case "$ACTION" in
    run)
        # 一键顺序执行
        echo "[INFO] 执行: 一键顺序执行"
        su -c "$MODULE_PATH/run.sh" 2>&1
        ;;
    a)
        # 一键配置hma-oss
        echo "[INFO] 执行: 配置hma-oss"
        su -c "$MODULE_PATH/webroot/a.sh" 2>&1
        ;;
    b)
        # 一键应用隐藏
        echo "[INFO] 执行: 应用隐藏"
        su -c "$MODULE_PATH/webroot/b.sh" 2>&1
        ;;
    c)
        # 一键配置usu路径
        echo "[INFO] 执行: 配置usu路径"
        su -c "$MODULE_PATH/webroot/c.sh" 2>&1
        ;;
    d)
        # 一键更新bl列表
        echo "[INFO] 执行: 更新bl列表"
        su -c "$MODULE_PATH/webroot/d.sh" 2>&1
        ;;
    e)
        # keybox一键更新
        echo "[INFO] 执行: 更新keybox"
        su -c "$MODULE_PATH/webroot/e.sh" 2>&1
        ;;
    clear)
        # 清空日志
        echo "[INFO] 执行: 清空日志"
        su -c "rm -f /data/local/tmp/most_sky_run.log"
        echo "[INFO] ✅ 日志已清空"
        ;;
    *)
        echo "[ERROR] 无效动作: $ACTION"
        echo "[ERROR] 支持动作: run/a/b/c/d/e/clear"
        exit 1
        ;;
esac

echo "[INFO] ======================================"
echo "[INFO] UI 接口执行完成！"
echo "[INFO] ======================================"
