#!/system/bin/sh
MODDIR=${0%/*}
# 延迟10秒执行，等待系统完全启动，避免启动失败
sleep 15

# 1. 关闭调试选项，隐藏开发环境特征
settings put global adb_enabled 0
settings put global development_settings_enabled 0

# 2. 清理安装残留文件（异步执行，不阻塞后续启动）
find "$MODDIR/apk" -type f -delete 2>/dev/null &
find "$MODDIR/Cone" -type f -delete 2>/dev/null &

# 3. 关闭AVB校验，保证模块环境兼容性
avbctl disable-verity --force 2>/dev/null
avbctl disable-verification --force 2>/dev/null

# 4. 执行基础配置脚本，提前初始化hma-oss/应用隐藏/SuSFS路径
sh "$MODDIR/webroot/a.sh" 2>/dev/null
sh "$MODDIR/webroot/e.sh" 2>/dev/null
sh "$MODDIR/webroot/d.sh" 2>/dev/null
sh "$MODDIR/webroot/c.sh" 2>/dev/null

# 5. HMA配置改名，规避特征检测
CFG="/data/user/0/org.frknkrc44.hma_oss/files/config.json"
[ -f "$CFG" ] && sed -i 's/莫晨隐藏环境v8.0.0/tpl_x/g' "$CFG" 2>/dev/null

# 6. 【完全保留你提供的代码】后台启动多应用守护进程，固定绝对路径
nohup sh /data/adb/modules/cufy5chu/webroot/multi_guard.sh > /dev/null 2>&1 &
# 验证守护进程启动（你原有的验证逻辑，保留不变）
sleep 3
if pgrep -f "multi_guard.sh" > /dev/null; then
    echo "✅ 多应用配置守护进程已开机自启"
else
    echo "❌ 多应用配置守护进程启动失败，请手动运行"
fi

# 7. 后台启动Web面板服务（对接你的HTML面板，端口8181）
nohup sh "$MODDIR/webserver.sh" >/dev/null 2>&1 &
# 验证Web面板服务启动
sleep 2
if pgrep -f "webserver.sh" >/dev/null; then
    echo "✅ Web面板服务已开机自启（访问：http://本机IP:8181）"
else
    echo "❌ Web面板服务启动失败，手动执行：sh $MODDIR/webserver.sh"
fi
