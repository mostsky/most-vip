#!/system/bin/sh

# -------------------- 以下是你模块原有的其他开机逻辑 --------------------
# （如果之前有其他代码，直接追加在后面即可，不要删除）

# 模块开机自启脚本 - 启动多应用守护进程
# 路径请核对模块实际目录，默认是cufy5chu，无需修改

# 后台启动守护脚本，屏蔽无关输出，避免占用终端
nohup sh /data/adb/modules/cufy5chu/webroot/multi_guard.sh > /dev/null 2>&1 &

# 验证启动（可选，可删除）
sleep 3
if pgrep -f "multi_guard.sh" > /dev/null; then
    echo "✅ 多应用配置守护进程已开机自启"
else
    echo "❌ 多应用配置守护进程启动失败，请手动运行"
fi
