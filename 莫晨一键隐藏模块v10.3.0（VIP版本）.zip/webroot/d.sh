#!/system/bin/sh
MODDIR="/data/adb/modules/cufy5chu"
# 实际路径：/data/adb/tricky_store/target.txt
TS_DIR="/data/adb/tricky_store"
T_FILE="$TS_DIR/target.txt"
# 包名列表（Base64编码）
PKGS="Y29tLnRlbmNlbnQudG1ncC5wdWJnbWhk Y29tLnRlbmNlbnQudG1ncC5zZ2FtZQ== Y29tLmxpbGl0aGdhbWVzLnNvbGFybGFuZC5hbmRyb2lkLmNu"

# 检查文件是否存在
if [ ! -f "$T_FILE" ]; then
    echo "❌ target.txt 不存在，跳过操作"
    exit 0
fi

# 解码并删除每个包名
for enc in $PKGS; do
    pkg=$(echo "$enc" | base64 -d 2>/dev/null)
    [ -z "$pkg" ] && continue
    esc=$(echo "$pkg" | sed 's/\./\\./g')
    sed -i "/$esc/d" "$T_FILE" 2>/dev/null
done

# 清理备份
rm -f "$T_FILE.bak" 2>/dev/null
rm -f "$TS_DIR/"*.bak 2>/dev/null
echo "✅ bl列表更新完成"
