#!/system/bin/sh
# 莫晨 批量隐藏应用 - 读取配置文件
# 支持：Android 7~16
LIST="/data/adb/modules/cufy5chu/webroot/mochen_hide.list"

log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

if [ ! -f "$LIST" ]; then
    log "❌ 配置文件不存在：$LIST"
    exit 1
fi

log "==== 开始批量隐藏 ===="
log "配置文件：$LIST"

while read -r PKG; do
    PKG=$(echo "$PKG" | xargs)
    if [ -z "$PKG" ] || [[ "$PKG" == "#"* ]]; then
        continue
    fi

    log "→ 处理：$PKG"

    pm disable --user 0 "$PKG" >/dev/null 2>&1
    pm hide --user 0 "$PKG" >/dev/null 2>&1

    for DIR in \
        /data/app/*/"$PKG"* \
        /data/app/"$PKG"* \
        /data/adb/modules/*/"$PKG"* \
        /data/media/0/Android/"$PKG"*
    do
        if [ -e "$DIR" ]; then
            chmod 000 "$DIR" >/dev/null 2>&1
            chattr +i "$DIR" >/dev/null 2>&1
            mount -o remount,ro "$DIR" >/dev/null 2>&1
        fi
    done

    log "✅ 隐藏完成：$PKG"
done < "$LIST"

log "==== 全部隐藏完毕 ===="
