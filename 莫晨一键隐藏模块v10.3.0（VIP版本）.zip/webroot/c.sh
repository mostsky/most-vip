#!/system/bin/sh

# 源文件路径
FROM="/data/adb/modules/cufy5chu/webroot/susfs_config.xml"
# 目标路径
TO="/data/user/0/com.sukisu.ultra/shared_prefs/susfs_config.xml"

# 等待目录就绪
sleep 1

# 复制并覆盖
cp -f "$FROM" "$TO"

# 修复权限（适配 shared_prefs）
chmod 600 "$TO"
chown 1000:1000 "$TO"

# 可选：给 APP 权限
chcon u:object_r:app_data_file:s0 "$TO" 2>/dev/null
