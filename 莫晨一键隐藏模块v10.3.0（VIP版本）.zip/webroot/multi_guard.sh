#!/system/bin/sh
# 莫晨一键隐藏模块 - 多应用守护 & Web守护
# 兼容：所有面具 / 所有安卓 / 不卡机 / 不耗电

MODDIR="${0%/*}"
while [ -n "$MODDIR" ] && [ ! -f "$MODDIR/module.prop" ]; do
  MODDIR="${MODDIR%/*}"
done

LOG_FILE="/data/local/tmp/cufy5chu_guard.log"
LOCK_FILE="/data/local/tmp/.cufy5chu_guard.lock"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 秒启后台 + 防重复
(
  if [ -f "$LOCK_FILE" ]; then
    exit 0
  fi
  touch "$LOCK_FILE"

  log "✅ 多应用守护已启动"

  # 统一权限
  chmod -R 755 "$MODDIR/webroot" 2>/dev/null

  run() {
    local f="$MODDIR/webroot/$1"
    [ -f "$f" ] && {
      chmod 755 "$f"
      log "▶️ 执行 $1"
      sh "$f" >> "$LOG_FILE" 2>&1
    }
  }

  # 执行全套配置
  run a.sh
  run b.sh
  run c.sh
  run d.sh
  run e.sh
  run 1.sh

  log "✅ 基础脚本执行完成"

  # ======================
  # SuSFS 配置自动同步
  # ======================
  FROM="$MODDIR/webroot/susfs_config.xml"
  TO_DIR="/data/user/0/com.sukisu.ultra/shared_prefs"
  TO="$TO_DIR/susfs_config.xml"
  PKG="com.sukisu.ultra"

  if [ -f "$FROM" ]; then
    mkdir -p "$TO_DIR"
    cp -af "$FROM" "$TO"
    chmod 600 "$TO"
    chcon u:object_r:app_data_file:s0 "$TO" 2>/dev/null

    APPID=$(dumpsys package "$PKG" | grep userId | head -n1 | sed 's/.*=//g')
    [ -n "$APPID" ] && chown "$APPID:$APPID" "$TO"

    log "✅ SuSFS 配置已同步 & 权限修复"
  fi

  # ======================
  # Web 面板启动 + 守护
  # ======================
  WEB_SH="$MODDIR/webserver.sh"
  start_web() {
    [ -f "$WEB_SH" ] || return
    nohup sh "$WEB_SH" >/dev/null 2>&1 &
    log "🌐 Web 面板已启动"
  }

  start_web

  # 轻量守护循环
  while true; do
    if ! pgrep -f "webserver.sh" >/dev/null 2>&1; then
      start_web
      log "🔧 Web 面板已自动重启"
    fi
    sleep 10
  done

) &
