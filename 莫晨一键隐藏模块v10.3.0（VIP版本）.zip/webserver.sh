#!/system/bin/sh
MODDIR=${0%/*}

# 基础权限
chmod -R 0755 "$MODDIR" 2>/dev/null
chown -R root:root "$MODDIR" 2>/dev/null

# 网页根目录
WEBROOT="$MODDIR/webroot"
PORT=8181

# 检查网页目录
if [ ! -d "$WEBROOT" ]; then
    echo "Web目录不存在: $WEBROOT"
    exit 1
fi

# 结束旧进程
pkill -f "busybox httpd" 2>/dev/null
pkill -f "httpd $PORT" 2>/dev/null

# 启动轻量HTTP服务器
if command -v busybox >/dev/null 2>&1; then
    busybox httpd -p "$PORT" -h "$WEBROOT"
else
    # 无busybox fallback
    python -m http.server "$PORT" --directory "$WEBROOT" 2>/dev/null &
fi

echo "Web面板运行在: http://0.0.0.0:$PORT"
