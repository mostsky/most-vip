#!/system/bin/sh

mkdir -p /data/adb/tricky_store
temp_log_file="/data/adb/tricky_store/update_log.tmp"
while true; do
    current_date=$(date +%Y-%m-%d)
    update_operation="已经更新一次"
    pm list packages -3 | sed ';s/package://g' >> /data/adb/tricky_store/target.txt
    sort -u /data/adb/tricky_store/target.txt -o /data/adb/tricky_store/target.txt
    echo "[$current_date] $update_operation" >> $temp_log_file
    temp_log_content=$(cat $temp_log_file)
    module_prop_path="/data/adb/modules/Hons-Tricky-Store/module.prop" 
    if [ -f "$module_prop_path" ]; then
        current_description=$(grep "^description=" "$module_prop_path" | cut -d '=' -f 2-)
        new_description="$current_description [Update Log: $temp_log_content]"
        sed -i "s/^description=.*/description=$new_description/" "$module_prop_path"    
        > $temp_log_file
    fi
    sleep 43200 
done
