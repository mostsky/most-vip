sh /data/adb/modules/usb/service.sh

echo "开发者模式已经打开，可以直接链接电脑了"
